package com.example.recyclerview;
// this program is a refinement of code that was provide by Professor Ugo Buy at UIC. | Joseph Lenaghan | UIN: 676805596 | 10/1/22
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> myList;
    int userChoice = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView nameView = (RecyclerView) findViewById(R.id.recycler_view);

        List<String> names = Arrays.asList("Shark", "Dog", "Gorilla", "Lion", "Tiger", "Bear");

        myList = new ArrayList<>();
        myList.addAll(names);

        //Define the listener with a lambda and access the list of names with the position passed in
      //  RVClickListener listener = (view, position)-> Toast.makeText(this, "position: "+position, Toast.LENGTH_LONG).show();

        //Define the listener with a lambda and access the name of the list item from the view
        RVClickListener listener = (view, position) -> {
            TextView name = (TextView) view.findViewById(R.id.textView);
            //Toast.makeText(this, name.getText(), Toast.LENGTH_SHORT).show();
            Intent nuIntent = new Intent(); // creating an intent to send the user to a wikipedia page about the animal
            nuIntent.setAction(Intent.ACTION_VIEW);
            nuIntent.setData(Uri.parse("https://en.wikipedia.org/wiki/" + name.getText())); // have to pass this with the intent so the OS can decide an app to handle the intent
            startActivity(nuIntent);
        };
        userChoice = 0; // program always starts as a grid, so the userChoice will alawys start at 0 by default
        MyAdapter adapter = new MyAdapter(myList, listener,userChoice,this);
        nameView.setHasFixedSize(true);
        nameView.setAdapter(adapter);
        nameView.setLayoutManager(new GridLayoutManager(this,2)); //use this line to see as a grid
        //nameView.setLayoutManager(new LinearLayoutManager(this)); //use this line to see as a standard vertical list


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){ // setting up the menu that the user will use to swap between layout
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.switch_layout, menu);
        return true;
    }

    @Override // here is the code that creates buttons for changing the layout depending on user's preference
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item1: // if the user desires a grid layout
                if(userChoice == 0){ // if the user is already in the grid layout, inform them of that fact
                    Toast.makeText(this,"You're already using this layout!",Toast.LENGTH_SHORT).show();
                    return true;
                }
                else { // if we got here, that means that the layout is not currently in grid layout, so change it!
                    userChoice = 0;
                    RVClickListener listener = (view, position) -> { // need to redeclare the recycler view's listener to guarantee functionality is maintained
                        TextView name = (TextView) view.findViewById(R.id.textView);
                        //Toast.makeText(this, name.getText(), Toast.LENGTH_SHORT).show();
                        Intent nuIntent = new Intent(); // creating an intent to send the user to a wikipedia page about the animal
                        nuIntent.setAction(Intent.ACTION_VIEW);
                        nuIntent.setData(Uri.parse("https://en.wikipedia.org/wiki/" + name.getText())); // have to pass this with the intent so the OS can decide an app to handle the intent
                        startActivity(nuIntent); // navigate away from this activity to the wikipedia page that was just parsed
                    };
                    RecyclerView nameView = (RecyclerView) findViewById(R.id.recycler_view);
                    MyAdapter adapter = new MyAdapter(myList, listener, userChoice,this); // pass 0 with the adapter so that it knows which layout to select
                    nameView.setHasFixedSize(true);
                    nameView.setAdapter(adapter);
                    nameView.setLayoutManager(new GridLayoutManager(this, 2)); //use this line to see as a grid
                    return true;
                }
            case R.id.item2: // if the user desires a linear layout
                if(userChoice == 1){ // if the user is already in the linear layout, inform them of that fact
                    Toast.makeText(this,"You're already using this layout!",Toast.LENGTH_SHORT).show();
                    return true;
                }
                else { // if we got here, that means that the layout is not currently in linear layout, so change it!
                    userChoice = 1; // update the user's choice to reflect the current layout
                    RVClickListener listener2 = (view, position) -> { // need to redeclare the recycler view's listener to guarantee functionality is maintained
                        TextView name = (TextView) view.findViewById(R.id.textView);
                        //Toast.makeText(this, name.getText(), Toast.LENGTH_SHORT).show();
                        Intent nuIntent = new Intent(); // creating an intent to send the user to a wikipedia page about the animal
                        nuIntent.setAction(Intent.ACTION_VIEW);
                        nuIntent.setData(Uri.parse("https://en.wikipedia.org/wiki/" + name.getText())); // have to pass this with the intent so the OS can decide an app to handle the intent
                        startActivity(nuIntent); // navigate away from this activity to the wikipedia page that was just parsed
                    };
                    RecyclerView nameView2 = (RecyclerView) findViewById(R.id.recycler_view);
                    MyAdapter adapter2 = new MyAdapter(myList, listener2,userChoice, this); // pass 1 with the adapter so that it knows which layout to select
                    nameView2.setHasFixedSize(true);
                    nameView2.setAdapter(adapter2);
                    nameView2.setLayoutManager(new LinearLayoutManager(this)); //use this line to see as a grid
                    return true;
                }

        }
        return super.onOptionsItemSelected(item);
    } // end of onOptionsItemSelected

    /*  //you can put the contextItem selected method here or use a listener in the ViewHolder class
    @Override
    public boolean onContextItemSelected(MenuItem item){
        Log.i("ON_CLICK","menu item clicked");

        return true;
    }
    */

}