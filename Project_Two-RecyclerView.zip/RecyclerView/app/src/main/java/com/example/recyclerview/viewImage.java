package com.example.recyclerview;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class viewImage extends AppCompatActivity { // using this activity to display the relevant image the user wished to see
    public ImageView image; // imageview to contain the image

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState); // standard operating procedure for line 16->18
        setContentView(R.layout.activity_viewimage);
        image = (ImageView) findViewById(R.id.imageView2);
        Intent i = getIntent(); // grab the intent that was passed to this activity
        String name = i.getStringExtra("animal"); // grabbing the name that was pased with the intent, we will use this to display the correct image
        Log.i("viewImage",name); // debugging log to see exactly what name was passed with the intent
        if(name.equals("Bear")){ // the user wishes to see the bear image
            image.setImageResource(R.drawable.bear); // grab the bear image from drawables
        }
        else if(name.equals("Dog")){ // the user wishes to see the dog image
            image.setImageResource(R.drawable.dog); // grab the dog image from drawables
        }
        else if(name.equals("Gorilla")){ // the user wishes to see the gorilla image
            image.setImageResource(R.drawable.gorilla); // grab the gorilla image from drawables
        }
        else if(name.equals("Lion")){ // the user wishes to see the lion image
            image.setImageResource(R.drawable.lion); // grab the lion image from drawables
        }
        else if(name.equals("Shark")){ // the user wishes to see the shark image
            image.setImageResource(R.drawable.shark); // grab the shark image from drawables
        }
        else if(name.equals("Tiger")){ // the user wishes to see the Tiger image
            image.setImageResource(R.drawable.tiger); // grab the tiger image from drawables
        }
    }
}
