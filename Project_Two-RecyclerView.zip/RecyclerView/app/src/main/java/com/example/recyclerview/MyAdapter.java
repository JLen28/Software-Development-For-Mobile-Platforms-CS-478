package com.example.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private ArrayList<String> nameList; //data: the names displayed
    private RVClickListener RVlistener; //listener defined in main activity
    private int userChoice;
    private View listView;
    private Context context;
    // private Context context;

    /*
    passing in the data and the listener defined in the main activity
     */
    public MyAdapter(ArrayList<String> theList, RVClickListener listener, int choice,Context nuContext){
        // save list of names to be displayed passed by main activity
        nameList = theList;
        userChoice = choice;
        context = nuContext;
        // save listener defined and passed by main activity
        this.RVlistener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Context context = parent.getContext();
        // get inflater and inflate XML layout file
        LayoutInflater inflater = LayoutInflater.from(context);
        if(userChoice == 0) { // this if else decides which layout we need to grab depending on the view the user wishes to see the app in
            listView = inflater.inflate(R.layout.rv_item, parent, false);
        }
        else{ // grab the other layout
            listView = inflater.inflate(R.layout.rv_item2, parent, false);
        }


        // create ViewHolder passing the view that it will wrap and the listener on the view
        ViewHolder viewHolder = new ViewHolder(listView, RVlistener); // create ViewHolder

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        // populate the item at the input position
        holder.name.setText(nameList.get(position));
        // this code block properly distributes all the images to their proper cell
        if(nameList.get(position) == "Bear"){
            holder.image.setImageResource(R.drawable.bear);
        }
        else if(nameList.get(position) == "Dog"){
            holder.image.setImageResource(R.drawable.dog);
        }
        else if(nameList.get(position) == "Gorilla"){
            holder.image.setImageResource(R.drawable.gorilla);
        }
        else if(nameList.get(position) == "Lion"){
            holder.image.setImageResource(R.drawable.lion);
        }
        else if(nameList.get(position) == "Shark"){
            holder.image.setImageResource(R.drawable.shark);
        }
        else if(nameList.get(position) == "Tiger"){
            holder.image.setImageResource(R.drawable.tiger);
        }

    }

    @Override
    public int getItemCount() {
        return nameList.size();
    }




    /*
        This class creates a wrapper object around a view that contains the layout for
         an individual item in the list. It also implements the onClickListener so each ViewHolder in the list is clickable.
        It's onclick method will call the onClick method of the RVClickListener defined in
        the main activity.
     */
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener{

        public TextView name;
        public ImageView image;
        private RVClickListener listener;
        private View itemView;

        public ViewHolder(@NonNull View itemView, RVClickListener passedListener) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.textView);
            image = (ImageView) itemView.findViewById(R.id.imageView);
            this.itemView = itemView;
            itemView.setOnCreateContextMenuListener(this); //set context menu for each list item (long click)
            this.listener = passedListener;

            /* don't forget to set the listener defined here to the view (list item) that was
                passed in to the constructor. */
            itemView.setOnClickListener(this); //set short click listener
        }

        @Override
        public void onClick(View v) {
            // getAdapterPosition() returns the position of the current ViewHolder in the adapter.
            listener.onClick(v, getAdapterPosition());
            Log.i("ON_CLICK", "in the onclick in view holder");
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

            //inflate menu from xml

            MenuInflater inflater = new MenuInflater(v.getContext());
            inflater.inflate(R.menu.context_menu, menu );
            menu.getItem(0).setOnMenuItemClickListener(onMenu); // this menu item directs the user to a webpage about the animal
            menu.getItem(1).setOnMenuItemClickListener(onImage); // this menu item directs the user to a new activity displaying a full size image
           // menu.getItem(2).setOnMenuItemClickListener(onMenu);
            //menu.getItem(3).setOnMenuItemClickListener(onMenu);

            //create menu in code

            menu.setHeaderTitle("Additional Options"); // set the header of the context menu

            //add menu items and set the listener for each
            //menu.add(0,v.getId(),0,"option 1").setOnMenuItemClickListener(onMenu);
            //menu.add(0,v.getId(),0,"option 2").setOnMenuItemClickListener(onMenu);
            //menu.add(0,v.getId(),0,"option 3").setOnMenuItemClickListener(onMenu);

        }

        /*
            listener for menu items clicked
         */
        private final MenuItem.OnMenuItemClickListener onMenu = new MenuItem.OnMenuItemClickListener(){ // this is the listener that handles the first menu option
            @Override
            public boolean onMenuItemClick(MenuItem item){
                Intent nuIntent = new Intent(); // creating an intent to send the user to a wikipedia page about the animal
                nuIntent.setAction(Intent.ACTION_VIEW);
                nuIntent.setData(Uri.parse("https://en.wikipedia.org/wiki/" + name.getText())); // have to pass this with the intent so the OS can decide an app to handle the intent
                context.startActivity(nuIntent); // navigate to the webpage
                return true;
            }
        };
        private final MenuItem.OnMenuItemClickListener onImage = new MenuItem.OnMenuItemClickListener(){ // this is the listener that handles the second menu option
            @Override
            public boolean onMenuItemClick(MenuItem item){
                Intent nuIntent = new Intent(context,viewImage.class); // creating an intent to send the user to a wikipedia page about the animal
                nuIntent.putExtra("animal",name.getText()); // add the relevant name to the intent so it can be accessed in the second activity
                context.startActivity(nuIntent); // navigate to the image view activity
                return true;
            }
        };



    }
}
