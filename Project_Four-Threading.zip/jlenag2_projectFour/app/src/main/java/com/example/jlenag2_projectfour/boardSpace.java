package com.example.jlenag2_projectfour;
// code by Joseph Lenaghan for CS 478 project four | UIN : 676805596 | 11/10/22
// made this class to make it easier for programmatically determining who owns the boardSpace, it would be a lot more difficult if done by determining color
public class boardSpace {
    boolean occupied;
    int owner;

    public boardSpace(){
        occupied = false; // occupied state starts false for initialization
        owner = -1; // owned by no-one so -1
    }

    public void setOwner(int new_owner){
        owner = new_owner; // will either be -1 for unoccupied, 0 for player one, or 1 for player two
    }

    public int getOwner(){
        return owner;
    }

    public void setOccupied(){ // set the boardSpace's state to occupied
        occupied = true;
    }

    public void unOccupy(){ // un-occupy  the boardSpace
        occupied = false;
    }

    public boolean isOccupied (){ // return whether or not the space is occupied
        if(this.occupied == true){ // its occupied
            return true;
        }
        else { // it's not
            return false;
        }
    }


}
