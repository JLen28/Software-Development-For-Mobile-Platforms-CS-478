package com.example.jlenag2_projectfour;
// code by Joseph Lenaghan for CS 478 project four | UIN : 676805596 | 11/10/22
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //-----------------------------------------------\\
    // these will be used by the threads to communicate with the worker threads that post messages to the UI thread's message handler
    public static final int PLACE_PIECE = 1;
    public static final int CHECK_WIN = 2;
    public static final int CHECK_TIE = 10;
    public static final int NEW_TURN = 11;
    public static final int WAIT = 12;
    public static final int ADD_PIECE = 13;
    public static final int SHUTDOWN = 99;
    // creating board spaces to manage the owner and occupied state of each of the board spaces
    public boardSpace b1 = new boardSpace();
    public boardSpace b2 = new boardSpace();
    public boardSpace b3 = new boardSpace();
    public boardSpace b4 = new boardSpace();
    public boardSpace b5 = new boardSpace();
    public boardSpace b6 = new boardSpace();
    public boardSpace b7 = new boardSpace();
    public boardSpace b8 = new boardSpace();
    public boardSpace b9 = new boardSpace();
    //-----------------------------------------------\\
    //declaring buttons outside of onCreate so they can be manipualated in the handler
    public Button boardspace_1; // top left boardspace
    public Button boardspace_2; // top middle boardspace
    public Button boardspace_3; // top right boardspace
    public Button boardspace_4; // middle left boardspace
    public Button boardspace_5; // middle boardsapce
    public Button boardspace_6; // middle right boardspace
    public Button boardspace_7; // bottom left boardspace
    public Button boardspace_8; // bottom middle boardspace
    public Button boardspace_9; // bottom right boardspace
    // ///
    public TextView winScreen;
    public static int moveCount = 0;
    public static boolean inProgress = false;
    private static Handler play1Handler;
    private static Handler play2Handler;
    public static List<boardSpace> board = new ArrayList<boardSpace>();
    public static List<Button> visual_board = new ArrayList<Button>();
    // This handler, running on the UI thread, will be our server
    private final Handler mHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            moveCount++;
            int what = msg.what;
            switch (what) {
                case PLACE_PIECE :
                    if(msg.arg1 == 0){ // player one's turn
                        if(board.get(msg.arg2).isOccupied()){ // space is not free or I forgot to unOccupy() the space
                            Log.i("inside of UI handler","player one is attempting to place a space that is already occupied");
                            if(board.get(msg.arg2).getOwner() == 0){// player one tried to place a piece on a space it already owns
                                Log.i("inside of UI handler","Player one attempted to place a piece on a space it already occupies");
                                Message nuMsg = play1Handler.obtainMessage(NEW_TURN); // this space is occupied, player one needs to try again
                                nuMsg.arg1 = msg.arg2 + 1;
                                play1Handler.sendMessage(nuMsg); // send message to worker thread to try again with the next space over from this one
                                break;
                            }
                            else if(board.get(msg.arg2).getOwner() == 1){
                                Log.i("inside of UI handler","Player one attempted to place a piece on a space it's opponent occupies");
                                Message nuMsg = play1Handler.obtainMessage(NEW_TURN); // this space is occupied, player one needs to try again
                                nuMsg.arg1 = msg.arg2 + 1;
                                play1Handler.sendMessage(nuMsg); // send message to worker thread to try again with the next space over from this one
                                break;
                            }
                            else if(board.get(msg.arg2).getOwner() == -1){
                                Log.i("inside of UI handler","Programmer error, space is unoccupied but was never set to unoccupied!");
                                break;
                            }
                        }
                        else{ // space is not occupied, player one is good to occupy the space visually and programmatically
                            board.get(msg.arg2).setOccupied(); // occupy the space
                            board.get(msg.arg2).setOwner(0); // set the owner to be player one
                            visual_board.get(msg.arg2).setBackgroundColor(Color.parseColor("#06cc80")); // set color to green for player one
                            Message nuMsg = play1Handler.obtainMessage(ADD_PIECE);
                            nuMsg.arg1 = msg.arg2;
                            play1Handler.sendMessage(nuMsg);
                            nuMsg = play2Handler.obtainMessage(NEW_TURN);
                            nuMsg.arg1 = msg.arg2;
                            play2Handler.sendMessage(nuMsg);
                            break;
                        }
                    }
                    if(msg.arg1 == 1){ // player two's
                        if(board.get(msg.arg2).isOccupied()){ // space is not free or I forgot to unOccupy() the space
                            Log.i("inside of UI handler","player two is attempting to place a space that is already occupied");
                            if(board.get(msg.arg2).getOwner() == 0){// player one tried to place a piece on a space it already owns
                                Log.i("inside of UI handler","Player two attempted to place a piece on a space it already occupies");
                                break;
                            }
                            else if(board.get(msg.arg2).getOwner() == 1){
                                Log.i("inside of UI handler","Player two attempted to place a piece on a space it's opponent occupies");
                                break;
                            }
                            else if(board.get(msg.arg2).getOwner() == -1){
                                Log.i("inside of UI handler","Programmer error, space is unoccupied but was never set to unoccupied!");
                                break;
                            }
                        }
                        else{ // space is not occupied, player one is good to occupy the space visually and programmatically
                            board.get(msg.arg2).setOccupied(); // occupy the space
                            board.get(msg.arg2).setOwner(1); // set the owner to be player two
                            visual_board.get(msg.arg2).setBackgroundColor(Color.parseColor("#1006cc")); // set color to blue for player two
                            Message nuMsg = play2Handler.obtainMessage(ADD_PIECE);
                            nuMsg.arg1 = msg.arg2;
                            play2Handler.sendMessage(nuMsg);
                            nuMsg = play1Handler.obtainMessage(NEW_TURN);
                            nuMsg.arg1 = msg.arg2;
                            play1Handler.sendMessage(nuMsg);
                            break;
                        }
                    }
                    else{
                        Log.i("inside of UI handler","msg.arg1 passed something other than 0 or 1, something went wrong, shouldn't get here");
                    } // end of PLACE_PIECE behavior
                case CHECK_WIN :
                    // time to call it a tie?
                    if(moveCount == 20){ // call it a tie
                        Log.i("inside of UI handler","game has taken to long, calling it a tie!");
                        winScreen.setText("This game is a tie!");
                        break;
                    }
                    //starting first by checking for horizontal win states
                    if(board.get(0).isOccupied() && board.get(1).isOccupied() && board.get(2).isOccupied()){ // top horizontal
                        if(board.get(0).getOwner() == board.get(1).getOwner() && board.get(0).getOwner() == board.get(2).getOwner()){
                            if(board.get(0).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 1,2, and 3");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(0).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 1,2, and 3");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of top horizontal behavior
                    else if(board.get(3).isOccupied() && board.get(4).isOccupied() && board.get(5).isOccupied()){ // middle horizontal
                        if(board.get(3).getOwner() == board.get(4).getOwner() && board.get(3).getOwner() == board.get(5).getOwner()){
                            if(board.get(3).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 4,5, and 6");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(3).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 4,5, and 6");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of middle horizontal behavior
                    else if(board.get(6).isOccupied() && board.get(7).isOccupied() && board.get(8).isOccupied()){ // bottom horizontal
                        if(board.get(6).getOwner() == board.get(7).getOwner() && board.get(6).getOwner() == board.get(8).getOwner()){
                            if(board.get(6).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 7,8, and 9");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(6).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 7,8, and 9");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of bottom horizontal behavior\
                    //checking now for vertical line win states
                    else if(board.get(0).isOccupied() && board.get(3).isOccupied() && board.get(6).isOccupied()){ // first vertical
                        if(board.get(0).getOwner() == board.get(3).getOwner() && board.get(0).getOwner() == board.get(6).getOwner()){
                            if(board.get(0).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 1,4, and 7");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(0).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 1,4, and 7");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of first vertical behavior
                    else if(board.get(1).isOccupied() && board.get(4).isOccupied() && board.get(7).isOccupied()){ // second vertical
                        if(board.get(1).getOwner() == board.get(4).getOwner() && board.get(1).getOwner() == board.get(7).getOwner()){
                            if(board.get(1).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 2,5, and 8");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(1).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 2,5, and 8");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of second vertical behavior
                    else if(board.get(2).isOccupied() && board.get(5).isOccupied() && board.get(8).isOccupied()){ // third vertical
                        if(board.get(2).getOwner() == board.get(5).getOwner() && board.get(2).getOwner() == board.get(8).getOwner()){
                            if(board.get(2).getOwner() == 0){
                                Log.i("inside of UI handler","player one wins with board space 3,6, and 9");
                                winScreen.setText("player one wins!");
                                break;
                            }
                            else if(board.get(2).getOwner() == 1){
                                Log.i("inside of UI handler","player two wins with board space 3,6, and 9");
                                winScreen.setText("player two wins!");
                                break;
                            }
                            else{
                                Log.i("inside of UI handler","all three spaces are occupied, but owner isn't 0 or 1, something is wrong");
                                break;
                            }
                        }
                    } // end of third vertical behavior
                    else{
                        Log.i("inside of UI handler","Checked for win state but none was found, breaking");
                        break;
                    }
            }
        }
    }; // UI handler that will handle messages sent by either of the two worker threads
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         boardspace_1 = findViewById(R.id.button1); // top left boardspace
         boardspace_2 = findViewById(R.id.button2); // top middle boardspace
         boardspace_3 = findViewById(R.id.button3); // top right boardspace
         boardspace_4 = findViewById(R.id.button4); // middle left boardspace
         boardspace_5 = findViewById(R.id.button5); // middle boardsapce
         boardspace_6 = findViewById(R.id.button6); // middle right boardspace
         boardspace_7 = findViewById(R.id.button7); // bottom left boardspace
         boardspace_8 = findViewById(R.id.button8); // bottom middle boardspace
         boardspace_9 = findViewById(R.id.button9); // bottom right boardspace
        winScreen = findViewById(R.id.textView);
        Button startButton = findViewById(R.id.buttonStart);
        // setting all the visual boardspaces to be gray representing they are unoccupied
        boardspace_1.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_2.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_3.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_4.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_5.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_6.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_7.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_8.setBackgroundColor(Color.parseColor("#b7a9c2"));
        boardspace_9.setBackgroundColor(Color.parseColor("#b7a9c2"));
        // list that will maintain all the programmatic board spaces interacted with by the threads
        board.add(b1);
        board.add(b2);
        board.add(b3);
        board.add(b4);
        board.add(b5);
        board.add(b6);
        board.add(b7);
        board.add(b8);
        board.add(b9);
        // list that will maintain all of the visual boardspaces the user will see on screen
        visual_board.add(boardspace_1);
        visual_board.add(boardspace_2);
        visual_board.add(boardspace_3);
        visual_board.add(boardspace_4);
        visual_board.add(boardspace_5);
        visual_board.add(boardspace_6);
        visual_board.add(boardspace_7);
        visual_board.add(boardspace_8);
        visual_board.add(boardspace_9);

        startButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Thread t1 = new PlayerOne();
                Thread t2 = new PlayerTwo();
                if(inProgress == false) {
                    t1.start();
                    t2.start();
                    inProgress = true;
                    Message msg = mHandler.obtainMessage(PLACE_PIECE);
                    msg.arg1 = 0;
                    msg.arg2 = 0;
                    mHandler.sendMessage(msg); // kicking things off
                }
                else{
                    Message msg = play1Handler.obtainMessage(SHUTDOWN);
                    play1Handler.sendMessage(msg);
                    msg = play2Handler.obtainMessage(SHUTDOWN);
                    play2Handler.sendMessage(msg);
                    clearBoard();
                    winScreen.setText("");
                    t1.start();
                    t2.start();
                    msg = mHandler.obtainMessage(PLACE_PIECE);
                    msg.arg1 = 0;
                    msg.arg2 = 0;
                    mHandler.sendMessage(msg); // kicking things off
                }
            }
        });
    }


    // This will be worker thread one
    public class PlayerOne extends Thread {
        public int numPieces = 3;
        public List<Integer> curSpaces = new ArrayList<Integer>();
        public void run() {
            Looper.prepare();
            play1Handler = new Handler(Looper.myLooper()) {
                public void handleMessage(Message msg){
                    int what = msg.what;
                    switch (what) {
                        case NEW_TURN:
                            moveCount++;
                            try {
                                Thread.sleep(2500); // sleep for 2 and half seconds so the play befor this one can be observed
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if(numPieces == 0){ // out of pieces to place, now the player must move around the pieces it's placed
                                Message nuMsg = mHandler.obtainMessage(CHECK_WIN);
                                mHandler.sendMessage(nuMsg);
                                return;
                            }
                            else { // player still has pieces to place
                                Message nuMsg = mHandler.obtainMessage(PLACE_PIECE);
                                nuMsg.arg1 = 0; // it's player one, this should be zero
                                if(msg.arg1 + 1 > 9){ // don't wan't to go out of bounds
                                    nuMsg.arg2 = msg.arg1 - 3;
                                }
                                else { // all is well, carry on
                                    nuMsg.arg2 = msg.arg1 + 1;
                                }
                                mHandler.sendMessage(nuMsg);
                                nuMsg = mHandler.obtainMessage(CHECK_WIN);
                                mHandler.sendMessage(nuMsg);
                                break;
                            }
                        case ADD_PIECE: // called when the player successfully places a piece onto the board
                            curSpaces.add(msg.arg1); // add to the list of boardspaces occupied by this player
                            numPieces--; // placed a piece, so de-increment
                            Log.i("inside thread one","board space selected: " + msg.arg1);
                            Log.i("inside thread one","size of list: " + curSpaces.size());
                            Log.i("inside thread one","number of pieces in use: " + curSpaces.size());
                            Log.i("inside thread one","number of pieces left: " + numPieces);
                        case SHUTDOWN :
                            return;
                    }
                }
            };
            Looper.loop();
        }
    }

    // This will be worker thread two
    public class PlayerTwo extends Thread {
        public int numPieces = 3;
        public List<Integer> curSpaces = new ArrayList<Integer>();
        public void run() {
            Looper.prepare();
            play2Handler = new Handler(Looper.myLooper()) {
                public void handleMessage(Message msg){
                    int what = msg.what;
                    switch (what) {
                        case NEW_TURN:
                            moveCount++;
                            try {
                                Thread.sleep(2500); // sleep for 2 and half seconds so the play befor this one can be observed
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if(numPieces == 0){ // out of pieces to place, now the player must move around the pieces it's placed
                                Message nuMsg = mHandler.obtainMessage(CHECK_WIN);
                                mHandler.sendMessage(nuMsg);
                                return;
                            }
                            else { // player still has pieces to place
                                Message nuMsg = mHandler.obtainMessage(PLACE_PIECE);
                                nuMsg.arg1 = 1; // it's player two, this should be one
                                if(msg.arg1 + 1 > 9){ // don't wan't to go out of bounds
                                    nuMsg.arg2 = msg.arg1 - 2;
                                }
                                else { // all is well, carry on
                                    nuMsg.arg2 = msg.arg1 + 2;
                                }
                                mHandler.sendMessage(nuMsg);
                                nuMsg = mHandler.obtainMessage(CHECK_WIN);
                                mHandler.sendMessage(nuMsg);
                                break;
                            }
                        case ADD_PIECE: // called when the player successfully places a piece onto the board
                            curSpaces.add(msg.arg1); // add to the list of boardspaces occupied by this player
                            numPieces--; // placed a piece, so de-increment
                            Log.i("inside thread two","board space selected: " + msg.arg1);
                            Log.i("inside thread two","size of list: " + curSpaces.size());
                            Log.i("inside thread two","number of pieces in use: " + curSpaces.size());
                            Log.i("inside thread two","number of pieces left: " + numPieces);

                        case SHUTDOWN :
                            return;

                    }
                }
            };
            Looper.loop();
        }
    }


    public void clearBoard(){
        b1.unOccupy();
        b2.unOccupy();
        b3.unOccupy();
        b4.unOccupy();
        b5.unOccupy();
        b6.unOccupy();
        b7.unOccupy();
        b8.unOccupy();
        b9.unOccupy();
        b1.setOwner(-1);
        b2.setOwner(-1);
        b3.setOwner(-1);
        b4.setOwner(-1);
        b5.setOwner(-1);
        b6.setOwner(-1);
        b7.setOwner(-1);
        b8.setOwner(-1);
        b9.setOwner(-1);
        boardspace_1.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_2.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_3.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_4.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_5.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_6.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_7.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_8.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
        boardspace_9.setBackgroundColor(Color.parseColor("#b7a9c2")); // set color to gray for unoccupied
    }



}

