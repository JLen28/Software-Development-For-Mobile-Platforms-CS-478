package com.example.myapplication;


import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.app.Activity;


import android.util.Log;
import android.widget.Toast;

public class MainActivity extends Activity {
    protected Button button1; // button user will interact with first
    protected Button button2; // button user will interact with after finishing up with the second activity
    protected int button2Flag = -1; // this flag will dictate how button2's listener reacts
    protected String phoneNum = " "; // string to hold the phone number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button); // button the user should use first
        button2 = (Button) findViewById(R.id.button2); // button the user should use after completing the first button's requests

        button1.setOnClickListener(button1Listener); // setting up the listener
        button2.setEnabled(false);
        button2.setOnClickListener(button2Listener);
    }

    public View.OnClickListener button1Listener = v -> moveToSecondAct(); // listener calls function

    private void moveToSecondAct() { // function that calls the second activity
        Intent i = new Intent(MainActivity.this,SecondActivity.class);
        startActivityForResult(i,2); // starting up the second activity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { // need to use this to capture the phone number sent from the second activity and determine if the result was good or bad
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 2) { // request code two is the code we used to denote the second activity
            if(resultCode == Activity.RESULT_OK) { // if the formatting on the phone number was correct
                Log.i("FirstActivity", "WE GOT HERE ON CORRECT FORMAT");
                phoneNum = data.getStringExtra("result"); // grabbing the phone number from the extras
                Log.i("FirstActivity", phoneNum + " THIS IS THE PHONE NUM FROM SECONDACTIVITY");
                button2.setEnabled(true); // enabling the second button
                button2Flag = 0; // setting flag for a valid phone number
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                // Write your code if there's no result
                Log.i("FirstActivity","WE GOT HERE ON INCORRECT FORMAT");
                phoneNum = data.getStringExtra("result"); // grabbing the invalid phone number from the extras
                Log.i("FirstActivity", phoneNum + " THIS IS THE PHONE NUM FROM SECONDACTIVITY");
                button2.setEnabled(true); // enabling the second button
                button2Flag = 1; // setting flag for an invalid phone number

            }
        }
    } //onActivityResult

    public View.OnClickListener button2Listener = v -> handleButtonTwo(button2Flag,phoneNum); // listener for second button
    private void handleButtonTwo(int flag,String number) { // function called by button2's listener
        if(flag == 1){ // if this is tripped, we have an invalid phone number and need to use a Toast message to inform the user
            Toast message = Toast.makeText(getApplicationContext(),number + " Is not valid, Try again please.",Toast.LENGTH_SHORT);
            message.show(); // show the user the message
        }
        if(flag == 0){ // if this is tripped, we have a valid phone number and need to create an intent to use the phone app
            Log.i("FirstActivity","GOT TO THIS FLAG");
            Intent last = new Intent(); // declaring new intent
            last.setAction(Intent.ACTION_DIAL); // setting an action so we can get to the phone app
            last.setData(Uri.parse("tel:+" + phoneNum)); // using a URI parse to pass the phone number in the correct format to the phone app
            startActivity(last); // start the phone app
        }

    }
}

