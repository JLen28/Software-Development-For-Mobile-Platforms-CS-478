package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.app.Activity;
import android.content.Intent;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener; // use this for the edit text listeners



public class SecondActivity extends Activity {
    protected EditText phoneNum; // field where user inputs their phone number
    protected String number; // string to hold the phone number hit by the user
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("SecondActivity", "Activity completed onCreate method") ;
        setContentView(R.layout.second_activity); // standard procedure till line 28
        phoneNum = (EditText) findViewById(R.id.editTextPhone);
        phoneNum.setOnEditorActionListener(phoneNumList);
    }
    public TextView.OnEditorActionListener phoneNumList = new OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            number = phoneNum.getText().toString(); // grabbing the input from the EditText
            Log.i("SecondActivity",number + " Phone number");
            // phone number should ONLY be of size 14(second format w/ optional space), 13(second format w/o optional space) or 10(1st format)
            if(number.length() == 10){ // checking formatting of the first format type i.e '3125551212'
                for(int j = 0; j < number.length(); j++){ // checking each character of the phone number to make sure it is truly valid
                    int num = Character.getNumericValue(number.charAt(j)); // checking if the value is within 0 -> 9, otherwise illegal
                    if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                        Log.i("SecondActivity",number + " Phone number not valid");
                        Intent returnIntent = new Intent(); // declaring intent to return to first activity
                        String result = " "; // string array to hold the phone number and the message
                        result = number; // phone number
                        returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                        setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                        finish(); // return to first activity
                        return false;
                    }
                }
                Log.i("SecondActivity",number + " Phone number was valid!");
                Intent returnIntent = new Intent(); // declaring intent to return to first activity
                String result = " "; // string array to hold the phone number and the message
                result = number; // phone number
                returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                setResult(Activity.RESULT_OK,returnIntent); // correct input, so result code is to RESULT_OK
                finish(); // return to first activity
                return true;

            } // end of 1st format
            if(number.length() == 13){ // Beginning of 2nd format w/o optional space
                if(number.charAt(0) == '(' && number.charAt(4) == ')' && number.charAt(8) == '-'){ // needs to have these
                    Log.i("SecondActivity",number + " GOT HERE GOT HERE GOT HERE");
                    for(int j = 1; j < 4; j++){ // check between parentheses
                        int num = Character.getNumericValue(number.charAt(j)); // checking if the value is within 0 -> 9, otherwise
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    for(int k = 5; k < 8; k++ ){ // check between closing parentheses and the dash
                        int num = Character.getNumericValue(number.charAt(k)); // checking if the value is within 0 -> 9, otherwise illegal
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    for(int l = 9; l < number.length(); l++ ){ // checking the rest of the string
                        int num = Character.getNumericValue(number.charAt(l)); // checking if the value is within 0 -> 9, otherwise illegal
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    Log.i("SecondActivity",number + " Phone number was valid!");
                    Intent returnIntent = new Intent(); // declaring intent to return to first activity
                    String result = " "; // string array to hold the phone number and the message
                    result = number; // phone number
                    returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                    setResult(Activity.RESULT_OK,returnIntent); // correct input, so result code is to RESULT_OK
                    finish(); // return to first activity
                    return true;

                }
                else { // INPUT IS INCORRECT!!!
                    Log.i("SecondActivity",number + " Phone number not valid");
                    Intent returnIntent = new Intent(); // declaring intent to return to first activity
                    String result = " "; // string array to hold the phone number and the message
                    result = number; // phone number
                    returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                    setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                    finish(); // return to first activity
                    return false;
                }
            } // end 2nd format without optional space
            if(number.length() == 14){ //beginning of 2nd format w/ optional space
                if(number.charAt(0) == '(' && number.charAt(4) == ')' && number.charAt(5) == ' ' && number.charAt(9) == '-'){ // needs to have these
                    Log.i("SecondActivity",number + " GOT HERE GOT WITH SPACE");
                    for(int j = 1; j < 4; j++){ // check between parentheses
                        int num = Character.getNumericValue(number.charAt(j)); // checking if the value is within 0 -> 9, otherwise
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    for(int k = 6; k < 9; k++ ){ // check between closing parentheses and the dash
                        int num = Character.getNumericValue(number.charAt(k)); // checking if the value is within 0 -> 9, otherwise illegal
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    for(int l = 10; l < number.length(); l++ ){ // checking the rest of the string
                        int num = Character.getNumericValue(number.charAt(l)); // checking if the value is within 0 -> 9, otherwise illegal
                        if(num < 0 || num > 9){ // INPUT IS INCORRECT!!!
                            Log.i("SecondActivity",number + " Phone number not valid");
                            Intent returnIntent = new Intent(); // declaring intent to return to first activity
                            String result = " "; // string array to hold the phone number and the message
                            result = number; // phone number
                            returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                            setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                            finish(); // return to first activity
                            return false;
                        }
                    }
                    Log.i("SecondActivity",number + " Phone number was valid!");
                    Intent returnIntent = new Intent(); // declaring intent to return to first activity
                    String result = " "; // string array to hold the phone number and the message
                    result = number; // phone number
                    returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                    setResult(Activity.RESULT_OK,returnIntent); // correct input, so result code is to RESULT_OK
                    finish(); // return to first activity
                    return true;

                }
                else { // INPUT IS INCORRECT!!!
                    Log.i("SecondActivity",number + " Phone number not valid");
                    Intent returnIntent = new Intent(); // declaring intent to return to first activity
                    String result = " "; // string array to hold the phone number and the message
                    result = number; // phone number
                    returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                    setResult(Activity.RESULT_CANCELED,returnIntent); // incorrect format, result code is set to RESULT_CANCELED
                    finish(); // return to first activity
                    return false;
                }

            } // end 2nd format with optional space
            else{ // not in format that is acceptable
                Log.i("SecondActivity",number + " Phone number not valid");
                Intent returnIntent = new Intent(); // declaring intent
                String result = " "; // string array to hold the phone number and the message
                result = number; // phone number
                returnIntent.putExtra("result",result); // adding the array to extras for the intent to take back to first activity
                setResult(Activity.RESULT_CANCELED,returnIntent); // valid incorrect, result code is set to RESULT_CANCELED
                finish();
                return false;
            } // end of not in acceptable format block

        }


     };

    }